﻿namespace Domain.Enums
{
	public enum ChatMode : byte
	{
		GuestPrivate,
		CardEditPrivate,
		PairingPrivate,
	}
}
