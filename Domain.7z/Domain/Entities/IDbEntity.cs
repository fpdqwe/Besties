﻿namespace Domain.Entities
{
	public interface IDbEntity
	{
		long GetPrimaryKey();
	}
}
